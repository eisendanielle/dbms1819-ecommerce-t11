module.exports = (function() {
  'use strict';

  var nonLoggedRoute = require ('express').Router();


return nonLoggedRoute;
})();
module.exports = (function() {
  'use strict';

  var guestRoute = require ('express').Router();


return guestRoute;
})();